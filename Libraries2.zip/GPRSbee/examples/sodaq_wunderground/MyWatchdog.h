#ifndef MYWATCHDOG_H_
#define MYWATCHDOG_H_

extern bool hz_flag;

void setupWatchdog();


#endif /* MYWATCHDOG_H_ */
